package com.example.insurancepremiumcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import java.text.DecimalFormat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var total : Double=0.0




        btnCalc.setOnClickListener(){
            total=getPremium()
            textView8.text=total.toString()
        }

        btnReset.setOnClickListener(){
            radioGroup.clearCheck()
            checkBoxYes.setChecked(false)
        }
    }
    fun getPremium():Double{
        return when(AgeRange.selectedItemPosition){
            0 -> 60.00
            1 -> 70.00 +
                    (if(radioButton3.isChecked) 50.00 else 0.0)+
                    (if(checkBoxYes.isChecked) 100.00 else 0.0)
            2 -> 90.00 +
                    (if(radioButton3.isChecked) 100.00 else 0.0)+
                    (if(checkBoxYes.isChecked) 150.00 else 0.0)
            3 -> 120.00+
                    (if(radioButton3.isChecked) 150.00 else 0.0)+
                    (if(checkBoxYes.isChecked)200.00 else 0.0)
            4 -> 150.00 +
                    (if(radioButton3.isChecked) 200.00 else 0.0)+
                    (if(checkBoxYes.isChecked)250.00 else 0.0)
            else -> 150.00 +
                    (if(radioButton3.isChecked) 200.00 else 0.0)+
                    (if(checkBoxYes.isChecked)300.00 else 0.0)
        }
    }

}
